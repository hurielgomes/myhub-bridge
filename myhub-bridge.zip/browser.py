from __future__ import annotations

import logging
import re
import time
from pathlib import Path
from typing import Any

from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright


class MyHubBrowser:
    def __init__(self, config: dict[str, Any]):
        self.cfg = config
        root = Path(__file__).resolve().parent
        self.profile = root / config["paths"]["profile"]
        self.profile.mkdir(parents=True, exist_ok=True)
        self.pw = self.context = self.page = None
        self.last_capture: dict[str, Any] | None = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def open(self, chat_url: str | None = None) -> None:
        self.pw = sync_playwright().start()
        self.context = self.pw.chromium.launch_persistent_context(
            user_data_dir=str(self.profile),
            headless=False,
            viewport=self.cfg["browser"]["viewport"],
        )
        self.page = self.context.pages[0] if self.context.pages else self.context.new_page()
        self.page.goto(chat_url or self.cfg["url"], wait_until="domcontentloaded")
        self.page.wait_for_timeout(1200)
        logging.info("Página aberta: %s", self.page.url)

    def close(self) -> None:
        try:
            if self.context:
                self.context.close()
        finally:
            if self.pw:
                self.pw.stop()
            self.context = self.pw = self.page = None

    def visible(self, selectors: list[str]):
        for selector in selectors:
            try:
                locator = self.page.locator(selector).first
                if locator.count() and locator.is_visible():
                    return locator
            except Exception:
                continue
        return None

    def ensure_login(self) -> None:
        indicators = self.cfg["selectors"].get("login_indicators", [])
        if self.visible(indicators):
            input("O MyHub parece solicitar login. Entre na conta na janela e pressione ENTER aqui...")
        if self.visible(indicators):
            raise RuntimeError("A página ainda parece estar na tela de login.")

    def composer(self):
        candidates = self.cfg["selectors"].get("composer", []) + [
            'textarea[placeholder]',
            "textarea",
            '[contenteditable="true"][role="textbox"]',
            '[contenteditable="true"]',
            '[role="textbox"]',
        ]
        locator = self.visible(candidates)
        if not locator:
            raise RuntimeError(
                "Campo de mensagem não localizado. Ajuste selectors.composer em config.json."
            )
        return locator

    def _assistant_messages(self):
        custom = self.cfg["selectors"].get("assistant_messages", [])
        if custom:
            for selector in custom:
                try:
                    loc = self.page.locator(selector)
                    if loc.count():
                        return loc
                except Exception:
                    continue

        # Estrutura observada na interface MyHub utilizada no teste funcional.
        selector = (
            "//div[contains(concat(' ', normalize-space(@class), ' '), ' max-w-[812px] ')]"
            "/div[contains(concat(' ', normalize-space(@class), ' '), ' space-y-4 ')]"
            "/div[contains(concat(' ', normalize-space(@class), ' '), ' flex-col ') "
            "and not(contains(concat(' ', normalize-space(@class), ' '), ' max-w-[600px] '))]"
        )
        return self.page.locator(f"xpath={selector}")

    def assistant_capture(self) -> dict[str, Any]:
        """Captura texto e blocos de código da última mensagem do assistente."""
        try:
            messages = self._assistant_messages()
            for index in range(messages.count() - 1, -1, -1):
                message = messages.nth(index)
                content = message.locator(
                    "xpath=.//div[contains(concat(' ', normalize-space(@class), ' '), ' flex-1 ') "
                    "and contains(concat(' ', normalize-space(@class), ' '), ' min-w-0 ') "
                    "and contains(concat(' ', normalize-space(@class), ' '), ' break-words ')]"
                    "/div[contains(concat(' ', normalize-space(@class), ' '), ' space-y-4 ')]"
                )
                if not content.count():
                    # Se o seletor customizado já aponta diretamente para o conteúdo.
                    content = message
                text = content.last.inner_text().strip() if content.count() else ""
                if not text:
                    continue

                code_blocks: list[dict[str, str]] = []
                code_nodes = content.last.locator("pre") if content.count() else message.locator("pre")
                for code_index in range(code_nodes.count()):
                    pre = code_nodes.nth(code_index)
                    code = pre.locator("code")
                    source = code.first if code.count() else pre
                    code_text = source.inner_text().strip("\n")
                    classes = " ".join(filter(None, [
                        source.get_attribute("class"), pre.get_attribute("class")
                    ]))
                    language_match = re.search(r"language-([\w+#.-]+)", classes, re.I)
                    language = language_match.group(1) if language_match else "text"
                    filename = (
                        source.get_attribute("data-filename")
                        or pre.get_attribute("data-filename")
                        or source.get_attribute("title")
                        or pre.get_attribute("title")
                    )
                    code_blocks.append({
                        "index": str(code_index + 1),
                        "language": language,
                        "filename": filename or "",
                        "content": code_text,
                    })

                return {"text": text, "code_blocks": code_blocks}
        except Exception:
            logging.exception("Erro ao capturar mensagem do assistente")
        return {"text": "", "code_blocks": []}

    def assistant_text(self) -> str:
        return str(self.assistant_capture().get("text", ""))

    def generating(self) -> bool:
        selectors = self.cfg["selectors"].get("stop_generating", []) + [
            'button[aria-label*="Parar" i]',
            'button[aria-label*="Stop" i]',
            'button:has-text("Parar geração")',
            'button:has-text("Stop generating")',
        ]
        return self.visible(selectors) is not None

    def select_model(self, model_name: str | None) -> None:
        """Seleciona um modelo apenas quando os seletores da interface foram configurados."""
        if not model_name:
            return
        model_cfg = self.cfg.get("model_selection", {})
        trigger_selectors = model_cfg.get("trigger_selectors", [])
        option_templates = model_cfg.get("option_selectors", [])
        verify_templates = model_cfg.get("verify_selectors", [])
        if not trigger_selectors or not option_templates:
            raise RuntimeError(
                f"A solicitação pede o modelo '{model_name}', mas a seleção automática ainda "
                "não foi configurada. Configure model_selection em config.json ou deixe 'model': null."
            )

        trigger = self.visible(trigger_selectors)
        if not trigger:
            raise RuntimeError("Não localizei o menu de modelos do MyHub. Nenhuma mensagem foi enviada.")
        trigger.click()
        self.page.wait_for_timeout(300)
        option_selectors = [s.replace("{model}", model_name) for s in option_templates]
        option = self.visible(option_selectors)
        if not option:
            raise RuntimeError(
                f"O menu abriu, mas a opção exata '{model_name}' não foi localizada. "
                "Nenhuma mensagem foi enviada."
            )
        option.click()
        self.page.wait_for_timeout(400)
        if verify_templates:
            verifiers = [s.replace("{model}", model_name) for s in verify_templates]
            if not self.visible(verifiers):
                raise RuntimeError(
                    f"Não consegui confirmar a seleção do modelo '{model_name}'. "
                    "A mensagem não foi enviada para evitar usar um modelo incorreto."
                )
        logging.info("Modelo solicitado selecionado: %s", model_name)

    def send_and_collect_capture(self, prompt: str) -> dict[str, Any]:
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("Prompt vazio.")

        box = self.composer()
        before_count = self._assistant_messages().count()
        previous = self.assistant_text()
        try:
            box.fill(prompt)
        except Exception:
            box.click()
            self.page.keyboard.insert_text(prompt)

        send_candidates = self.cfg["selectors"].get("send_button", []) + [
            'button[aria-label*="Enviar" i]',
            'button[title*="Enviar" i]',
            'button[aria-label*="Send" i]',
            'button[type="submit"]',
            'button:has-text("Enviar")',
            'button:has-text("Send")',
        ]
        button = self.visible(send_candidates)
        if button and button.is_enabled():
            button.click()
        elif self.cfg["send"].get("keyboard", "Enter") == "Control+Enter":
            box.press("Control+Enter")
        else:
            box.press("Enter")

        logging.info("Prompt enviado; aguardando resposta.")
        deadline = time.monotonic() + int(self.cfg["timeouts"]["response_seconds"])
        stable_seconds = float(self.cfg["timeouts"]["stable_seconds"])
        last_text = ""
        stable_at: float | None = None
        seen_new_message = False

        while time.monotonic() < deadline:
            self.page.wait_for_timeout(800)
            capture = self.assistant_capture()
            current = str(capture.get("text", "")).strip()
            current_count = self._assistant_messages().count()
            if current_count > before_count or (current and current != previous):
                seen_new_message = True
            if seen_new_message and current:
                if current == last_text:
                    if stable_at is None:
                        stable_at = time.monotonic()
                else:
                    last_text = current
                    stable_at = None
                if (not self.generating() and stable_at is not None
                        and time.monotonic() - stable_at >= stable_seconds):
                    self.last_capture = capture
                    return capture

        if last_text:
            self.last_capture = self.assistant_capture()
            return self.last_capture

        raise PlaywrightTimeoutError(
            "Tempo esgotado aguardando a resposta. Confira a janela do MyHub e os seletores."
        )

    def send_and_collect(self, prompt: str) -> str:
        return str(self.send_and_collect_capture(prompt).get("text", ""))

    @property
    def current_url(self) -> str:
        return self.page.url if self.page else ""
