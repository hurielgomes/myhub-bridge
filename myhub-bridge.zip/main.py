from __future__ import annotations

import argparse
import json
import logging
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from artifacts import save_result
from browser import MyHubBrowser
from chat_store import ChatStore
from jobs import load_job

ROOT = Path(__file__).resolve().parent
CFG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


def timestamp_now() -> str:
    return datetime.now().astimezone().isoformat()


def output_path(job_id: str) -> Path:
    base = ROOT / CFG["paths"].get("results", "results") / job_id
    if not base.exists():
        return base
    suffix = datetime.now().strftime("_%Y%m%d_%H%M%S")
    return base.with_name(base.name + suffix)


def process_job(job: dict[str, Any], *, confirm: bool = True) -> Path | None:
    prompt = job["prompt"]
    chat_key = str(job["chat_key"])
    model = job.get("model")
    chat_store = ChatStore(ROOT / CFG["paths"].get("chat_registry", "data/chat_registry.json"))
    chat_record = chat_store.get(chat_key)
    chat_url = chat_record.get("url") if chat_record else None
    saved_model = chat_record.get("model") if chat_record else None
    selected_model = str(model) if model else saved_model

    print("\n========== NOVA SOLICITAÇÃO ==========")
    print(f"Projeto: {job.get('project')}")
    print(f"Finalidade: {job.get('purpose')}")
    print(f"Conversa: {chat_key} ({'existente' if chat_url else 'nova'})")
    print(f"Modelo: {model or (saved_model or 'padrão atual do MyHub')}")
    print(f"Prompt: {prompt[:1200]}{'…' if len(prompt) > 1200 else ''}")
    if confirm and input("\nEnviar ao MyHub? [S/n]: ").strip().lower() not in ("", "s", "sim"):
        print("Solicitação cancelada; nenhum prompt foi enviado.")
        return None

    with MyHubBrowser(CFG) as client:
        client.open(chat_url)
        client.ensure_login()

        # Modelo explícito: seleção automatizada configurada ou confirmação manual.
        if model and model != saved_model:
            if job.get("manual_model_selection"):
                input(
                    f"\nSelecione manualmente '{model}' na interface do MyHub. "
                    "Quando o nome estiver selecionado, pressione ENTER aqui..."
                )
            else:
                client.select_model(str(model))
        elif job.get("manual_model_selection") and not saved_model:
            input("\nSelecione o modelo desejado na interface do MyHub e pressione ENTER aqui...")
            typed_model = input("Informe o nome do modelo que acabou de selecionar (ou ENTER para não registrar): ").strip()
            selected_model = typed_model or None

        capture = client.send_and_collect_capture(prompt)
        final_url = client.current_url
        if not final_url:
            raise RuntimeError("O navegador não informou a URL da conversa.")
        chat_store.save(
            chat_key,
            final_url,
            model=selected_model,
            project=str(job.get("project", "")),
            purpose=str(job.get("purpose", "")),
        )

    job_id = str(job.get("_job_id") or job.get("id") or datetime.now().strftime("job_%Y%m%d_%H%M%S"))
    folder = output_path(job_id)
    save_result(
        folder,
        {k: v for k, v in job.items() if not k.startswith("_")},
        capture,
        provider="MyHubIA via Playwright",
        timestamp=timestamp_now(),
        chat_key=chat_key,
        chat_url=final_url,
        selected_model=selected_model,
    )
    print("\n===== RESPOSTA CAPTURADA =====\n")
    print(capture.get("text", ""))
    print(f"\nBlocos de código: {len(capture.get('code_blocks', []))}")
    print("Resultado salvo em:", folder)
    if capture.get("code_blocks"):
        print("Artefatos salvos em:", folder / "artifacts")
    return folder


def process_inbox(*, confirm: bool = True, watch: bool = False) -> int:
    inbox = ROOT / CFG["paths"].get("inbox", "inbox")
    processing = ROOT / CFG["paths"].get("processing", "processing")
    processed = ROOT / CFG["paths"].get("processed", "processed")
    failed = ROOT / CFG["paths"].get("failed", "failed")
    for directory in (inbox, processing, processed, failed):
        directory.mkdir(parents=True, exist_ok=True)

    total = 0
    failures = 0
    print(f"Aguardando solicitações JSON/TXT em: {inbox}")
    while True:
        jobs = sorted([*inbox.glob("*.json"), *inbox.glob("*.txt")])
        if not jobs:
            if not watch:
                break
            time.sleep(2)
            continue
        for source in jobs:
            working = processing / source.name
            try:
                shutil.move(str(source), str(working))
                job = load_job(working)
                result_folder = process_job(job, confirm=confirm)
                if result_folder is None:
                    shutil.move(str(working), str(inbox / source.name))
                    print(f"Solicitação mantida na inbox: {source.name}")
                    if watch:
                        time.sleep(2)
                    continue
                destination = processed / source.name
                if destination.exists():
                    destination = processed / f"{source.stem}_{datetime.now():%Y%m%d_%H%M%S}{source.suffix}"
                shutil.move(str(working), str(destination))
                total += 1
            except Exception as exc:
                logging.exception("Falha ao processar solicitação %s", source.name)
                print(f"\nFALHA em {source.name}: {exc}")
                failures += 1
                if working.exists():
                    destination = failed / source.name
                    if destination.exists():
                        destination = failed / f"{source.stem}_{datetime.now():%Y%m%d_%H%M%S}{source.suffix}"
                    shutil.move(str(working), str(destination))
            if watch:
                # Uma instância por vez: o perfil persistente do Chromium não é compartilhável.
                time.sleep(1)
        if not watch:
            break
    print(f"Solicitações concluídas nesta execução: {total}; falhas: {failures}")
    return 1 if failures else 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Ponte local entre arquivos de solicitação e MyHubIA.")
    parser.add_argument("--login", action="store_true", help="Abre o MyHub para login manual.")
    parser.add_argument("--prompt", help="Envia um prompt rápido (sem arquivo JSON).")
    parser.add_argument("--job", help="Caminho para um arquivo de solicitação JSON ou TXT.")
    parser.add_argument("--inbox", action="store_true", help="Processa uma vez os arquivos JSON/TXT da pasta inbox.")
    parser.add_argument("--watch", action="store_true", help="Monitora inbox continuamente.")
    parser.add_argument("--yes", action="store_true", help="Não solicita confirmação antes do envio.")
    args = parser.parse_args()

    (ROOT / CFG["paths"].get("logs", "logs")).mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        filename=ROOT / CFG["paths"].get("logs", "logs") / "myhub-bridge.log",
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )

    try:
        if args.login:
            with MyHubBrowser(CFG) as client:
                client.open()
                input("Faça login no MyHub. Quando o chat estiver pronto, pressione ENTER aqui...")
                print("Perfil local salvo em:", ROOT / CFG["paths"]["profile"])
            return 0

        if args.job:
            job = load_job(Path(args.job))
            process_job(job, confirm=not args.yes)
            return 0

        if args.inbox or args.watch:
            return process_inbox(confirm=not args.yes, watch=args.watch)

        prompt = args.prompt or CFG["test_prompt"]
        job = {
            "id": "teste_rapido_" + datetime.now().strftime("%Y%m%d_%H%M%S"),
            "project": "myhub_bridge",
            "purpose": "teste_rapido",
            "chat_key": "myhub_bridge__teste_rapido",
            "model": None,
            "prompt": prompt,
            "expected_outputs": [],
        }
        job["_job_id"] = job["id"]
        process_job(job, confirm=not args.yes)
        return 0
    except KeyboardInterrupt:
        print("\nInterrompido.")
        return 130
    except Exception as exc:
        logging.exception("Falha na execução")
        print("\nERRO:", exc)
        print("Consulte README.md para instruções de configuração.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
